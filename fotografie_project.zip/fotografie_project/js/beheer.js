const hideDiv = document.getElementsByClassName('hidden-Div');

const btn = document.getElementsByClassName('button-Show');

for (let i =0; i < btn.length; i++) {
    btn[i].addEventListener('click', () => {
        if(hideDiv[i].style.display === 'block') {
            hideDiv[i].style.display = 'none';
        }
        else {
            hideDiv[i].style.display = 'block';
        }
    });
}

