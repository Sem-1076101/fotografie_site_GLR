 <?php

 include './inc/auth.php';
 $Auth = new modAuth();

 include './inc/graph.php';

 include "config.php";
if ($Auth->userName === '87315@glr.nl') {
    header('Location: beheerPagina.php');
} else {
    header('Location: profiel.php');
}

