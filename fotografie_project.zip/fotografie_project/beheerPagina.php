<?php
include './inc/auth.php';
$Auth = new modAuth();
include './inc/graph.php';
include "config.php";

//bruining@glr.nl

if ($Auth->userName === '86712@glr.nl') {

} else {
    header('Location: overzicht.php');
}


$std = str_replace("@glr.nl", "", $Auth->userName);
$query = "SELECT DISTINCT * FROM profiel WHERE goedgekeurd = 'neutraal'";


$result = mysqli_query($mysqli, $query);


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Beheer Pagina</title>
    <link rel="stylesheet" href="css/beheer.css">

</head>

<body>
<nav>
    <div class="logo">
        <img src=img/glr-logo.webp alt="Logo Image">
    </div>
    <div class="hamburger">
        <div class="bars1"></div>
        <div class="bars2"></div>
        <div class="bars3"></div>
    </div>
    <ul class="nav-links">
        <li><a href="./home.php">Welkom</a></li>
        <li><a href="./overzicht.php">Deelnemers</a></li>
        <li><a href="./crowdfunding.php">Waarom crowdfunding</a></li>
        <li><a href="./contact.php">Contact</a></li>
    </ul>
</nav>
<script>
    const hamburger = document.querySelector(".hamburger");
    const navLinks = document.querySelector(".nav-links");
    const links = document.querySelectorAll(".nav-links li");

    hamburger.addEventListener('click', () => {
        //Links
        navLinks.classList.toggle("open");
        links.forEach(link => {
            link.classList.toggle("fade");
        });

        //Animation
        hamburger.classList.toggle("toggle");
    });
</script>

<div class="container-Beheer">
    <?php
    //voor profiel
    while ($item = mysqli_fetch_assoc($result)) {
        //voor tegenprestatie
        $email = $item['email'];
        $query2 = "SELECT DISTINCT * FROM tegenprestatie WHERE studentnummer= '$email'";
        $result2 = mysqli_query($mysqli, $query2);

        $queryFoto = "SELECT DISTINCT * FROM fotos WHERE studentnummer= '$email'";
        $resultFoto = mysqli_query($mysqli, $queryFoto);

        ?>
        <div class="test">
            <div class="info-Beheer">
                <button class="button-Show">Student: <?php echo $item['naam']; ?> </button>

                <div class="hidden-Div">
                    <p><strong>Email:</strong> <?php echo $item['email']; ?></p>
                    <p><strong>Doelbedrag:</strong> <?php echo $item['doelBedrag']; ?></p>
                    <p><strong>Gedoneerd:</strong> <?php echo $item['gedoneerd']; ?></p>
                    <table class="table-Hidden">
                        <tr>
                            <th class="tableKleur">Tegenprestatie</th>
                            <th class="tableKleur">Bedrag:</th>
                        </tr>
                        <?php
                        while ($item2 = $result2->fetch_assoc()) {
                            ?>
                            <tr>
                                <td class="tableKleur2"><?= $item2['tegenprestatie']; ?></td>
                                <td class="tableKleur2"><?= $item2['bedrag']; ?></td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                    <p><strong>Foto:</strong> <br> <img src="<?= $item['foto']; ?>" width="250px"></p>

                    <p>
                        <?php
                        while ($itemFoto = mysqli_fetch_assoc($resultFoto)) {
                            ?>
                            <img src="./fotos/<?= $itemFoto['foto']; ?>" width="150px">
                            <?php
                        }
                        ?>
                    </p>
                    <p>
                        <iframe class="iframe" width="500" height="315" src="<?= $item['video']; ?>"
                                title="YouTube video player" frameborder="0"
                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                allowfullscreen></iframe>
                    </p>
                    <p><strong>Omschrijving:</strong> <br>
                        <?php echo $item['omschrijving']; ?>
                    </p>
                    <p>

                    <form action="beheerPaginaVerwerk.php" method="post" class="formJa">
                        <input type="hidden" name="IDJa" value="<?= $item['id']; ?>">
                        <button class="button button--fenrir" type="submit" name="submitJa">
                            <svg aria-hidden="true" class="progress" width="70" height="70" viewbox="0 0 70 70">
                                <path class="progress__circle"
                                      d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"/>
                                <path class="progress__path"
                                      d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"
                                      pathLength="1"/>
                            </svg>
                            <span>Ja</span>
                        </button>
                    </form>

                    <p>
                    <form action="beheerPaginaVerwerk.php" method="post" class="formNee">
                        <input type="hidden" name="IDNee" value="<?= $item['id']; ?>">
                        <input type="hidden" name="email" value="<?= $email ?>">
                        <button class="button button--fenrir" type="submit" name="submitNee">
                            <svg aria-hidden="true" class="progress" width="70" height="70" viewbox="0 0 70 70">
                                <path class="progress__circle"
                                      d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"/>
                                <path class="progress__path"
                                      d="m35,2.5c17.955803,0 32.5,14.544199 32.5,32.5c0,17.955803 -14.544197,32.5 -32.5,32.5c-17.955803,0 -32.5,-14.544197 -32.5,-32.5c0,-17.955801 14.544197,-32.5 32.5,-32.5z"
                                      pathLength="1"/>
                            </svg>
                            <span>Nee</span>
                        </button>
                    </form>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }


    ?>
</div>

<script src="js/beheer.js" defer></script>

</body>
</html>