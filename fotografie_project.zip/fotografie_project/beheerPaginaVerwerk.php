<?php
require 'config.php';

if (isset($_POST['submitJa'])) {
    $id = $_POST['IDJa'];

    $query = "UPDATE profiel";
    $query .= " SET goedgekeurd = 'ja'";
    $query .= " WHERE ID=" . $id;

    $result = mysqli_query($mysqli, $query);

    if ($result) {
        echo "item is geupdate";
    } else {
        echo "FOUT bij toevoegen<br/>";
        echo $query . "<br/>"; //Tijdelijk (!) de query tonen
        echo mysqli_error($mysqli); //Tijdelijk (!) de foutmelding tonen
    }
}

if (isset($_POST['submitNee'])) {
    $id = $_POST['IDNee'];
    $email = $_POST['email'];
    $std = str_replace("@glr.nl", "", $email);

    $query = "DELETE FROM profiel WHERE ID = " . $id;
//    $query2 = "DELETE FROM tegenprestatie WHERE studentnummer =" . $studentnummer;
    $query2 = "DELETE FROM tegenprestatie WHERE studentnummer= $std";
    $queryFoto = "DELETE FROM fotos WHERE studentnummer = $std";
    $result = mysqli_query($mysqli, $query);
    $result2 = mysqli_query($mysqli, $query2);

    $resultFoto = mysqli_query($mysqli, $queryFoto);


    $status = unlink("./profiel_foto/" . $std . ".png");
    if ($status) {
        echo "";
    } else {
        echo "Er is iets fout gegaan.";
    }

    for ($i = 0; $i <= 2; $i++) {
        $status2 = unlink("./fotos/" . $std . "_" . $i . ".png");
        if ($status2) {
            echo "";
        } else {
            echo "Er is iets fout gegaan.";
        }
    }


    if ($result && $result2 && $resultFoto) {
        header("location: beheerPagina.php");
    } else {
        echo "FOUT bij toevoegen<br/>";
        echo $query . "<br/>"; //Tijdelijk (!) de query tonen
        echo $query2 . "<br/>"; //Tijdelijk (!) de query tonen
        echo mysqli_error($mysqli); //Tijdelijk (!) de foutmelding tonen
    }
}